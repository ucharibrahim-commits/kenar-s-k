package com.example.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class NotificationService : NotificationListenerService() {
    
    companion object {
        private const val TAG = "NotificationService"
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d(TAG, "Notification Listener connected successfully.")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        // Skip if the notification is from our own application to prevent infinite feedback loops
        if (sbn.packageName == packageName) {
            return
        }

        Log.d(TAG, "New notification detected from package: ${sbn.packageName}")
        
        // Show edge lighting animation for 5 seconds
        EdgeLightingManager.show(this, 5000)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        Log.d(TAG, "Notification removed from package: ${sbn?.packageName}")
    }
}
