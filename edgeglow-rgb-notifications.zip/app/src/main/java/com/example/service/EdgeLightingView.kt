package com.example.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import com.example.data.SettingsStore

class EdgeLightingView(context: Context) : View(context) {

    private val settingsStore = SettingsStore(context)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    
    private val drawRect = RectF()
    private var sweepGradient: SweepGradient? = null
    private val matrixLocal = Matrix()
    private var rotationAngle = 0f
    private var animator: ValueAnimator? = null

    init {
        // Force hardware acceleration for silky-smooth animations
        setLayerType(LAYER_TYPE_HARDWARE, null)
        setupAnimation()
    }

    private fun setupAnimation() {
        // Calculate speed duration. Speed scale: 1 (slow) to 5 (fast)
        val speedValue = settingsStore.speed.coerceIn(1f, 5f)
        val duration = when {
            speedValue <= 1f -> 4500L
            speedValue <= 2f -> 3200L
            speedValue <= 3f -> 2000L // default
            speedValue <= 4f -> 1200L
            else -> 600L
        }

        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = LinearInterpolator()
            addUpdateListener { animation ->
                rotationAngle = animation.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateShader(w.toFloat(), h.toFloat())
    }

    private fun updateShader(width: Float, height: Float) {
        if (width <= 0 || height <= 0) return

        val colors = when (settingsStore.colorMode) {
            SettingsStore.MODE_CYBERPUNK -> intArrayOf(
                0xFF00FFFF.toInt(), // Cyan
                0xFFFF00FF.toInt(), // Magenta
                0xFF00FFFF.toInt()  // Cyan wrap
            )
            SettingsStore.MODE_FIRE -> intArrayOf(
                0xFFFF0000.toInt(), // Red
                0xFFFF7F00.toInt(), // Orange
                0xFFFFFF00.toInt(), // Yellow
                0xFFFF0000.toInt()  // Red wrap
            )
            SettingsStore.MODE_AURORA -> intArrayOf(
                0xFF00FF87.toInt(), // Green
                0xFF60EFFF.toInt(), // Aqua
                0xFF00FF87.toInt()  // Green wrap
            )
            SettingsStore.MODE_GOLD -> intArrayOf(
                0xFFFFD700.toInt(), // Gold
                0xFFFFA500.toInt(), // Dark Orange
                0xFFFFF8DC.toInt(), // Cornsilk
                0xFFFFD700.toInt()  // Gold wrap
            )
            else -> intArrayOf( // MODE_RAINBOW
                0xFFFF0000.toInt(), // Red
                0xFFFF7F00.toInt(), // Orange
                0xFFFFFF00.toInt(), // Yellow
                0xFF00FF00.toInt(), // Green
                0xFF00FFFF.toInt(), // Cyan
                0xFF0000FF.toInt(), // Blue
                0xFFFF00FF.toInt(), // Violet
                0xFFFF0000.toInt()  // Red wrap
            )
        }

        // Relative positions for the gradient colors
        val positions = FloatArray(colors.size) { i -> i.toFloat() / (colors.size - 1) }

        sweepGradient = SweepGradient(width / 2f, height / 2f, colors, positions)
        paint.shader = sweepGradient
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val thicknessPx = settingsStore.thickness * resources.displayMetrics.density
        paint.strokeWidth = thicknessPx

        // Inset by half the thickness so the stroke doesn't get cut off at the edge of the window
        val halfThickness = thicknessPx / 2f
        drawRect.set(halfThickness, halfThickness, w - halfThickness, h - halfThickness)

        // Rotate the sweep gradient local matrix
        sweepGradient?.let { shader ->
            matrixLocal.setRotate(rotationAngle, w / 2f, h / 2f)
            shader.setLocalMatrix(matrixLocal)
        }

        // Use custom corner radius (in DP)
        val radiusPx = settingsStore.borderRadius * resources.displayMetrics.density
        canvas.drawRoundRect(drawRect, radiusPx, radiusPx, paint)
    }

    fun refreshSettings() {
        // Triggered when settings are changed in UI to dynamically refresh without restarting view
        setupAnimation()
        updateShader(width.toFloat(), height.toFloat())
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }
}
