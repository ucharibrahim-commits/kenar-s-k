package com.example.service

import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.WindowManager
import java.lang.Exception

object EdgeLightingManager {
    private const val TAG = "EdgeLightingManager"
    private var currentView: EdgeLightingView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val removeRunnable = Runnable {
        dismiss()
    }

    @Synchronized
    fun show(context: Context, durationMs: Long = 5000) {
        mainHandler.post {
            try {
                // Verify overlay drawing permissions
                if (!Settings.canDrawOverlays(context)) {
                    Log.w(TAG, "Cannot draw overlay: SYSTEM_ALERT_WINDOW permission is not granted.")
                    return@post
                }

                val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

                // Dismiss any existing lighting first to restart the animation cleanly
                if (currentView != null) {
                    mainHandler.removeCallbacks(removeRunnable)
                    try {
                        windowManager.removeView(currentView)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error removing old view", e)
                    }
                    currentView = null
                }

                val view = EdgeLightingView(context.applicationContext)
                
                // Set layout parameters for full screen overlay, drawing over status & navigation bars
                val params = WindowManager.LayoutParams().apply {
                    width = WindowManager.LayoutParams.MATCH_PARENT
                    height = WindowManager.LayoutParams.MATCH_PARENT
                    type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    format = PixelFormat.TRANSLUCENT
                }

                windowManager.addView(view, params)
                currentView = view

                // Automatically schedule dismissal after 5 seconds
                mainHandler.postDelayed(removeRunnable, durationMs)
                Log.d(TAG, "Edge lighting showing for $durationMs ms")

            } catch (e: Exception) {
                Log.e(TAG, "Failed to show edge lighting overlay", e)
            }
        }
    }

    @Synchronized
    fun dismiss() {
        mainHandler.post {
            try {
                if (currentView != null) {
                    val context = currentView!!.context
                    val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                    windowManager.removeView(currentView)
                    currentView = null
                    Log.d(TAG, "Edge lighting dismissed successfully")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to dismiss edge lighting overlay", e)
            } finally {
                mainHandler.removeCallbacks(removeRunnable)
            }
        }
    }

    fun isShowing(): Boolean {
        return currentView != null
    }
}
