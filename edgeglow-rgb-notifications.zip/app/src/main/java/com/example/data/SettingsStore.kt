package com.example.data

import android.content.Context
import android.content.SharedPreferences

class SettingsStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("edge_lighting_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_THICKNESS = "thickness"
        private const val KEY_SPEED = "speed"
        private const val KEY_COLOR_MODE = "color_mode"
        private const val KEY_CUSTOM_COLOR = "custom_color"
        private const val KEY_BORDER_RADIUS = "border_radius"

        // Color Modes
        const val MODE_RAINBOW = "RAINBOW"
        const val MODE_CYBERPUNK = "CYBERPUNK"
        const val MODE_FIRE = "FIRE"
        const val MODE_AURORA = "AURORA"
        const val MODE_GOLD = "GOLD"
    }

    var thickness: Float
        get() = prefs.getFloat(KEY_THICKNESS, 8f)
        set(value) = prefs.edit().putFloat(KEY_THICKNESS, value).apply()

    var speed: Float
        get() = prefs.getFloat(KEY_SPEED, 3f)
        set(value) = prefs.edit().putFloat(KEY_SPEED, value).apply()

    var colorMode: String
        get() = prefs.getString(KEY_COLOR_MODE, MODE_RAINBOW) ?: MODE_RAINBOW
        set(value) = prefs.edit().putString(KEY_COLOR_MODE, value).apply()

    var customColor: Int
        get() = prefs.getInt(KEY_CUSTOM_COLOR, 0xFF00FF00.toInt())
        set(value) = prefs.edit().putInt(KEY_CUSTOM_COLOR, value).apply()

    var borderRadius: Float
        get() = prefs.getFloat(KEY_BORDER_RADIUS, 40f)
        set(value) = prefs.edit().putFloat(KEY_BORDER_RADIUS, value).apply()
}
