package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyberpunk Dark Cosmic Palette
val DarkBackground = Color(0xFF080A10)
val DarkSurface = Color(0xFF111522)
val DarkSurfaceVariant = Color(0xFF1D2336)
val CyberCyan = Color(0xFF00E5FF)
val CyberPink = Color(0xFFFF007F)
val NeonPurple = Color(0xFF9D4EDD)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF8E9AA8)
val AccentGreen = Color(0xFF00E676)
val AccentOrange = Color(0xFFFF9100)
val CardBorder = Color(0xFF2B324D)
