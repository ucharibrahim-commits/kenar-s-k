package com.example

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SettingsStore
import com.example.service.EdgeLightingManager
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private lateinit var settingsStore: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsStore = SettingsStore(this)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    MainScreen(
                        settingsStore = settingsStore,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(settingsStore: SettingsStore, modifier: Modifier = Modifier) {
    val context = LocalContext.current

    // Observe permission states
    var isOverlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var isNotificationGranted by remember { mutableStateOf(isNotificationServiceEnabled(context)) }

    // Recheck permissions on launch & when user returns to app
    DisposableEffect(Unit) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                isOverlayGranted = Settings.canDrawOverlays(context)
                isNotificationGranted = isNotificationServiceEnabled(context)
            }
        }
        // Check on current thread since we are already in composition runtime
        isOverlayGranted = Settings.canDrawOverlays(context)
        isNotificationGranted = isNotificationServiceEnabled(context)
        onDispose {}
    }

    // Settings States
    var thickness by remember { mutableStateOf(settingsStore.thickness) }
    var speed by remember { mutableStateOf(settingsStore.speed) }
    var borderRadius by remember { mutableStateOf(settingsStore.borderRadius) }
    var selectedColorMode by remember { mutableStateOf(settingsStore.colorMode) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp, top = 16.dp)
    ) {
        // App Title / Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "EDGE LIGHTING",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 4.sp
                        ),
                        color = CyberCyan,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "RGB Bildirim Aydınlatması",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            letterSpacing = 1.sp
                        ),
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Live Mode Preview Card
        item {
            PreviewCard(colorMode = selectedColorMode)
        }

        // Permissions Warnings & Setup
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "SİSTEM İZİNLERİ",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp),
                    color = CyberPink
                )

                // Overlay Permission Card
                PermissionCard(
                    title = "Diğer Uygulamaların Üzerinde Gösterim",
                    description = "Kenar ışığı animasyonunun diğer uygulamalar ve kilit ekranı üzerinde çizilebilmesi için gereklidir.",
                    isGranted = isOverlayGranted,
                    onRequestPermission = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                        Toast.makeText(context, "Lütfen listeden uygulamayı seçip izni onaylayın.", Toast.LENGTH_LONG).show()
                    },
                    testTag = "overlay_permission_card"
                )

                // Notification Access Permission Card
                PermissionCard(
                    title = "Bildirim Erişim İzni",
                    description = "Yeni bir bildirim geldiğinde servisimizin bunu algılayıp ışığı tetiklemesi için gereklidir.",
                    isGranted = isNotificationGranted,
                    onRequestPermission = {
                        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                        context.startActivity(intent)
                        Toast.makeText(context, "Lütfen listeden 'Edge Lighting' servisini aktif edin.", Toast.LENGTH_LONG).show()
                    },
                    testTag = "notification_permission_card"
                )
            }
        }

        // Design Sliders
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, CardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "IŞIK VE ÇERÇEVE AYARLARI",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                        color = CyberCyan
                    )

                    // Thickness Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Çerçeve Kalınlığı", color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text("${thickness.toInt()} px", color = CyberCyan, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = thickness,
                            onValueChange = {
                                thickness = it
                                settingsStore.thickness = it
                            },
                            valueRange = 2f..24f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = CardBorder
                            ),
                            modifier = Modifier.testTag("thickness_slider")
                        )
                    }

                    // Speed Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Animasyon Hızı", color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text("${speed.toInt()}x", color = CyberCyan, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = speed,
                            onValueChange = {
                                speed = it
                                settingsStore.speed = it
                            },
                            valueRange = 1f..5f,
                            steps = 3,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = CardBorder
                            ),
                            modifier = Modifier.testTag("speed_slider")
                        )
                    }

                    // Corner Radius Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Köşe Yuvarlaklığı (Kavis)", color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text("${borderRadius.toInt()} dp", color = CyberCyan, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = borderRadius,
                            onValueChange = {
                                borderRadius = it
                                settingsStore.borderRadius = it
                            },
                            valueRange = 0f..80f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = CardBorder
                            ),
                            modifier = Modifier.testTag("radius_slider")
                        )
                    }
                }
            }
        }

        // Color Presets Selection
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "RGB RENK MODLARI",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp),
                    color = CyberCyan
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ColorModeItem(
                        name = "Rainbow",
                        desc = "Gökkuşağı",
                        mode = SettingsStore.MODE_RAINBOW,
                        colors = listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta),
                        isSelected = selectedColorMode == SettingsStore.MODE_RAINBOW,
                        onSelect = {
                            selectedColorMode = SettingsStore.MODE_RAINBOW
                            settingsStore.colorMode = SettingsStore.MODE_RAINBOW
                        },
                        modifier = Modifier.weight(1f)
                    )
                    ColorModeItem(
                        name = "Cyberpunk",
                        desc = "Siber Gece",
                        mode = SettingsStore.MODE_CYBERPUNK,
                        colors = listOf(CyberCyan, CyberPink, CyberCyan),
                        isSelected = selectedColorMode == SettingsStore.MODE_CYBERPUNK,
                        onSelect = {
                            selectedColorMode = SettingsStore.MODE_CYBERPUNK
                            settingsStore.colorMode = SettingsStore.MODE_CYBERPUNK
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ColorModeItem(
                        name = "Fire",
                        desc = "Ateş",
                        mode = SettingsStore.MODE_FIRE,
                        colors = listOf(Color.Red, Color(0xFFFF7F00), Color.Yellow),
                        isSelected = selectedColorMode == SettingsStore.MODE_FIRE,
                        onSelect = {
                            selectedColorMode = SettingsStore.MODE_FIRE
                            settingsStore.colorMode = SettingsStore.MODE_FIRE
                        },
                        modifier = Modifier.weight(1f)
                    )
                    ColorModeItem(
                        name = "Aurora",
                        desc = "Kutup Işığı",
                        mode = SettingsStore.MODE_AURORA,
                        colors = listOf(Color(0xFF00FF87), Color(0xFF60EFFF)),
                        isSelected = selectedColorMode == SettingsStore.MODE_AURORA,
                        onSelect = {
                            selectedColorMode = SettingsStore.MODE_AURORA
                            settingsStore.colorMode = SettingsStore.MODE_AURORA
                        },
                        modifier = Modifier.weight(1f)
                    )
                    ColorModeItem(
                        name = "Gold",
                        desc = "Altın",
                        mode = SettingsStore.MODE_GOLD,
                        colors = listOf(Color(0xFFFFD700), Color(0xFFCD7F32)),
                        isSelected = selectedColorMode == SettingsStore.MODE_GOLD,
                        onSelect = {
                            selectedColorMode = SettingsStore.MODE_GOLD
                            settingsStore.colorMode = SettingsStore.MODE_GOLD
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Test Action Button
        item {
            Button(
                onClick = {
                    if (!Settings.canDrawOverlays(context)) {
                        Toast.makeText(context, "Hata: Önce 'Diğer Uygulamaların Üzerinde Gösterim' iznini vermelisiniz!", Toast.LENGTH_LONG).show()
                    } else {
                        EdgeLightingManager.show(context, 5000)
                        Toast.makeText(context, "Edge Lighting 5 saniye boyunca aktif edildi!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("test_lighting_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberCyan,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Test Et")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "KENAR AYDINLATMASINI TEST ET (5 sn)",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                )
            }
        }

        // Instructions Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                border = BorderStroke(1.dp, CardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = "Nasıl Çalışır", tint = CyberCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Nasıl Çalışır?",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }
                    Text(
                        text = "1. Yukarıdaki iki sistem iznini de aktif edin.\n" +
                                "2. İstediğiniz renk modu, kalınlık, hız ve kavis değerlerini seçin.\n" +
                                "3. Telefonunuza yeni bir bildirim geldiğinde (örneğin SMS veya WhatsApp), ekran kapalı veya açık olsun, kenarlarda RGB akan ışık animasyonu 5 saniye boyunca otomatik olarak dönecektir.\n" +
                                "4. Reklamsız ve veri toplama yapmadan tamamen yerel çalışır.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PreviewCard(colorMode: String) {
    val gradientBrush = when (colorMode) {
        SettingsStore.MODE_CYBERPUNK -> Brush.horizontalGradient(listOf(CyberCyan, CyberPink, CyberCyan))
        SettingsStore.MODE_FIRE -> Brush.horizontalGradient(listOf(Color.Red, Color(0xFFFF7F00), Color.Yellow, Color.Red))
        SettingsStore.MODE_AURORA -> Brush.horizontalGradient(listOf(Color(0xFF00FF87), Color(0xFF60EFFF)))
        SettingsStore.MODE_GOLD -> Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFFCD7F32), Color(0xFFFFD700)))
        else -> Brush.horizontalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Blue, Color.Magenta, Color.Red))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // Flowing gradient representation card
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(gradientBrush)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkSurface)
                ) {
                    Text(
                        text = "AKTİF RENK AKIŞ ÖNİZLEMESİ",
                        color = TextPrimary,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        ),
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionCard(
    title: String,
    description: String,
    isGranted: Boolean,
    onRequestPermission: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        colors = CardDefaults.cardColors(
            containerColor = if (isGranted) DarkSurface else Color(0xFF221118)
        ),
        border = BorderStroke(
            1.dp,
            if (isGranted) CardBorder else Color(0xFFFF0055).copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            if (isGranted) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = AccentGreen.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, AccentGreen)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Granted",
                            tint = AccentGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "AKTİF",
                            color = AccentGreen,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            } else {
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberPink,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Uyarı",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "İZİN VER",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
fun ColorModeItem(
    name: String,
    desc: String,
    mode: String,
    colors: List<Color>,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .testTag("color_mode_$mode"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DarkSurfaceVariant else DarkSurface
        ),
        border = BorderStroke(
            2.dp,
            if (isSelected) CyberCyan else CardBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Visual Color Strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Brush.horizontalGradient(colors))
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = desc,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = if (isSelected) CyberCyan else TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = name,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

// Utility function to check Notification Listener Service state
fun isNotificationServiceEnabled(context: Context): Boolean {
    val pkgName = context.packageName
    val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
    if (!flat.isNullOrEmpty()) {
        val names = flat.split(":")
        for (name in names) {
            val cn = ComponentName.unflattenFromString(name)
            if (cn != null && cn.packageName == pkgName) {
                return true
            }
        }
    }
    return false
}
